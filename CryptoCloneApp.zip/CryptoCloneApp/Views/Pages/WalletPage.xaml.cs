namespace CryptoCloneApp.Views.Pages;

public partial class WalletPage : ContentPage
{
	public WalletPage()
	{
		InitializeComponent();
	}
}