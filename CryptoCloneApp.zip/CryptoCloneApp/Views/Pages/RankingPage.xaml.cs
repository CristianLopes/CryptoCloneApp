namespace CryptoCloneApp.Views.Pages;

public partial class RankingPage : ContentPage
{
	public RankingPage()
	{
		InitializeComponent();
	}
}