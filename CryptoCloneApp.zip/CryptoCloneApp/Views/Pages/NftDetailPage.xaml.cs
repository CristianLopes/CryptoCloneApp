namespace CryptoCloneApp.Views.Pages;

public partial class NftDetailPage : ContentPage
{
	public NftDetailPage()
	{
		InitializeComponent();
	}
}