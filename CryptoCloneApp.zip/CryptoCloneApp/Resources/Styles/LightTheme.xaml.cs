namespace CryptoCloneApp.Resources.Styles;

public partial class LightTheme : ResourceDictionary
{
	public LightTheme()
	{
		InitializeComponent();
	}
}