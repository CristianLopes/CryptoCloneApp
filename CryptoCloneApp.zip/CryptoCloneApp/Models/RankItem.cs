﻿namespace CryptoCloneApp.Models
{
    public class RankItem
    {
        public int Position { get; set; }
        public string Image { get; set; }
        public string Name { get; set; }
        public string Instagram { get; set; }
        public string EthAmount { get; set; }
        public string PercentageVariation { get; set; }
    }
}
