﻿namespace CryptoCloneApp.Models
{
    public enum NftType
    {
        Graphic2D,
        Graphic3D, 
        Gif,
        Illustration
    }
}
