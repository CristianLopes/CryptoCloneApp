﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace CryptoCloneApp.ViewModels
{
    public partial class RankingPageViewModel : ViewModelBase
    {
    }
}
