﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace CryptoCloneApp.ViewModels
{
    public partial class ProfilePageViewModel : ViewModelBase
    {
    }
}
